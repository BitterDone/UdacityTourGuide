package com.example.danielbitter.udacitytourguide;

/**
 * Created by danielbitter on 12/13/16.
 */

public class Word {
    private String mainWord;

    public Word(String s){
        this.mainWord = s;
    }

    public String getMainWord(){
        return this.mainWord;
    }
}
