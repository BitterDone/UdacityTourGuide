package com.example.danielbitter.udacitytourguide;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by danielbitter on 12/13/16.
 */

public class WordAdapter extends ArrayAdapter<Word> {
    private final Context context;
    private final ArrayList<Word> values;

    public WordAdapter(Context context, ArrayList<Word> values) {
        super(context, 0, values);
        this.context = context;
        this.values = values;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        TextView listItemWord = (TextView) listItem.findViewById(R.id.list_item_word);
        Word word = values.get(position);
        listItemWord.setText(word.getMainWord());

        return listItem;
    }
}
