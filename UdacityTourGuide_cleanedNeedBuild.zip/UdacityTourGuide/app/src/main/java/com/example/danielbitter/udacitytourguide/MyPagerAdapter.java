package com.example.danielbitter.udacitytourguide;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by danielbitter on 12/13/16.
 */

public class MyPagerAdapter extends FragmentPagerAdapter {
    private String tabTitles[];
    private Context context;

    public MyPagerAdapter(FragmentManager fm, Context c) {
        super(fm);
        this.context = c;

        tabTitles = new String[6];
        tabTitles[0] = context.getString(R.string.category_one);
        tabTitles[1] = context.getString(R.string.category_two);
        tabTitles[2] = context.getString(R.string.category_three);
        tabTitles[3] = context.getString(R.string.category_four);
        tabTitles[4] = context.getString(R.string.category_five);
        tabTitles[5] = context.getString(R.string.category_six);
    }

        @Override
        public Fragment getItem(int position) {
            switch(position) {
                case 0: return new FragmentCatOne();
                case 1: return new FragmentCatOne();
                case 2: return new FragmentCatOne();
                case 3: return new FragmentCatOne();
                case 4: return new FragmentCatOne();
                case 5: return new FragmentCatOne();
                default: return new FragmentCatOne();
            }
        }

        @Override
        public int getCount() {
            return tabTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
        return tabTitles[position];
    }
    }
