package com.example.danielbitter.udacitytourguide;


import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentCatOne extends Fragment {


    public FragmentCatOne() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        
        String[] wordsArray = new String[]{
                getString(R.string.one_item_one),
                getString(R.string.one_item_two),
                getString(R.string.one_item_three),
                getString(R.string.one_item_four),
                getString(R.string.one_item_five),
                getString(R.string.one_item_six),
                getString(R.string.one_item_seven),
                getString(R.string.one_item_eight),
                getString(R.string.one_item_nine),
                getString(R.string.one_item_ten),
        };
        
        ArrayList<Word> words = new ArrayList<Word>();
        
        for(int i=0;i<wordsArray.length;++i){
            words.add(i, new Word(wordsArray[i]));
        }

        WordAdapter adapter = new WordAdapter(getActivity(), words);
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        listView.setAdapter(adapter);

        return rootView;
    }

}
